import random
from .constants import BOARD_SIZE, SHIP, WATER, FLEET

def _ship_cells(start, length, horizontal):
    row, col = start
    if horizontal:
        return [(row, col + i) for i in range(length)]
    return [(row + i, col) for i in range(length)]
def _can_place(board, cells):
    for r, c in cells:
        if not (0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE): return False
        # Проверка самой клетки и соседей (8 направлений)
        for dr in range(-1, 2):
            for dc in range(-1, 2):
                nr, nc = r + dr, c + dc
                if 0 <= nr < BOARD_SIZE and 0 <= nc < BOARD_SIZE:
                    if board[nr][nc] == SHIP: return False
    return True
def random_place_fleet(board):
    while True:
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE): board[r][c] = WATER
        success = True
        for length in FLEET:
            placed = False
            for _ in range(100):
                horizontal = random.choice([True, False])
                start = (random.randint(0, 9), random.randint(0, 9))
                cells = _ship_cells(start, length, horizontal)
                if _can_place(board, cells):
                    for r, c in cells: board[r][c] = SHIP
                    placed = True
                    break
            if not placed:
                success = False
                break
        if success: break