from .constants import BOARD_SIZE, SHIP, WATER

def create_board():
    return [[WATER for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
def render_board(board, show_ships=True):
    header = "    " + " ".join([chr(ord('A') + i) for i in range(BOARD_SIZE)])
    print(header)
    for i, row in enumerate(board):
        row_str = []
        for cell in row:
            if not show_ships and cell == SHIP:
                row_str.append(WATER)
            else:
                row_str.append(cell)
        print(f"{i + 1:2} | {' '.join(row_str)}")
def has_ships_left(board):
    for row in board:
        if SHIP in row:
            return True
