BOARD_SIZE = 10
WATER = '.'
SHIP = 'S'
HIT = 'X'
MISS = '*'
FLEET = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1]