from .constants import BOARD_SIZE, WATER, SHIP, HIT, MISS
def parse_shot(text):
    text = text.strip().upper()
    if not text or len(text) < 2: return None
    col_letter = text[0]
    row_num = text[1:]
    if not col_letter.isalpha() or not row_num.isdigit(): return None

    col = ord(col_letter) - ord('A')
    row = int(row_num) - 1

    if 0 <= row < BOARD_SIZE and 0 <= col < BOARD_SIZE:
        return row, col
    return None
def apply_shot(board, shot):
    row, col = shot
    cell = board[row][col]

    if cell == SHIP:
        board[row][col] = HIT
        return "hit"
    elif cell == WATER:
        board[row][col] = MISS
        return "miss"
    else:
        return "repeat"