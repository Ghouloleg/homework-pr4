import os
from .board import create_board, render_board, has_ships_left
from .ships import random_place_fleet
from .shots import parse_shot, apply_shot


def clear_screen(): os.system('cls' if os.name == 'nt' else 'clear')


def play_game():
    b1, b2 = create_board(), create_board()
    random_place_fleet(b1)
    random_place_fleet(b2)

    current = 1
    boards = {1: b1, 2: b2}

    while True:
        clear_screen()
        me, enemy = (1, 2) if current == 1 else (2, 1)
        print(f" ХОД ИГРОКА {current}")
        print("\nВаше поле:")
        render_board(boards[me], show_ships=True)
        print("\nПоле противника:")
        render_board(boards[enemy], show_ships=False)

        text = input(f"\nИгрок {current}, ваш выстрел (напр. A5): ")
        shot = parse_shot(text)

        if not shot:
            input("Ошибка ввода! Нажмите Enter...")
            continue

        res = apply_shot(boards[enemy], shot)

        if res == "hit":
            if not has_ships_left(boards[enemy]):
                clear_screen()
                print(f"ПОБЕДААААААААААААААА! Игрок {current} разгромил лоха!")
                break
            input("ПАПАЛЛЛЛЛЛЛЛЛЛ")
        elif res == "miss":
            input("мимо,ЛООООООООООООООООООООООХ")
            current = enemy
        else:
            input("сюда уже пострел, харе бразер")