from game.game import play_game

if __name__ == "__main__":
    play_game()